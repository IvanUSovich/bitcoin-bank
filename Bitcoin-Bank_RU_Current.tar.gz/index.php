<?php
session_start();
require_once 'data.php';
$time_ = md5(time() - 86400 + 400);
$_SESSION['time_csrf'] = $time;
$secret = $_SERVER['SERVER_NAME'];
$csrf = md5($time . $secret);
$country_code = $geo["geoplugin_countryCode"];
?>
<!DOCTYPE html><html lang="ru"><head>
        <!-- cnv_pixel -->
        <script async="" src="js/fbevents.js"></script><script>
            var wrapUrlWithClickId=(function(){"use strict";function n(n,r){var e;void 0===r&&(r="uclick");var u=null===(e=n.match(/\?.+?$/))||void 0===e?void 0:e[0];return u?Array.from(u.matchAll(new RegExp("[?&](clickid|"+r+")=([^=&]*)","g"))).map((function(n){return{name:n[1],value:n[2]}})):[]}function r(n){var r=n();return 0===r.length?{}:r.reduce((function(n,r){var e;return Object.assign(n,((e={})[r.name]=""+r.value,e))}),{})}function e(e){void 0===e&&(e="uclick");var u,i,t=r((function(){return(function(n){return void 0===n&&(n="uclick"),Array.from(document.cookie.matchAll(new RegExp("(?:^|; )(clickid|"+n+")=([^;]*)","g"))).map((function(n){return{name:n[1],value:n[2]}}))})(e)})),c=r((function(){return n(document.referrer,e)})),a=r((function(){return n(document.location.search,e)}));return(u=[e,"clickid"],i=[t,c,a],u.reduce((function(n,r){return n.concat(i.map((function(n){return[r,n]})))}),[])).map((function(n){return{name:n[0],value:n[1][n[0]]}})).find((function(n){return n.value}))||null}function u(n,r,e){var u=n.replace(new RegExp(r+"=[^=&]*","g"),r+"="+e);return-1!==u.indexOf(r)?u:(function(n,r,e){var u=n.trim(),i=r+"="+e;return-1===u.indexOf("?")?u+"?"+i:u.endsWith("?")?""+u+i:u+"&"+i})(n,r,e)}return function(n,r){void 0===r&&(r="uclick");var i=e(r);return null===i?n:n.includes("cnv_id")?i.name===r?u(n,i.name,i.value):i.value?u(n,"cnv_id",i.value):n:u(n,i.name,i.value)}})();

            function cnv_pixel(){
                var img = document.createElement('img');
                img.src = wrapUrlWithClickId('https://infoppabfx.xyz/click.php?cnv_id=09905ntwfa4c2c');
                img.referrerPolicy = 'no-referrer-when-downgrade';
            }
        </script>
        <meta charset="UTF-8">
        <meta name="facebook-domain-verification" content="{{fb_domain_verification}}">
        <meta name="robots" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bitcoin Bank</title>
        <link href="images/favicon.webp" rel="shortcut icon" type="image/png">
        <script src="js/jquery.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="js/bootstrap.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
        <link rel="stylesheet" type="text/css" href="css/checkbox-svg.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="./intl-tel-input/css/intlTelInput.css">

        <!-- form -->
        <link rel="stylesheet" href="css/form.css">

        <!-- Facebook Pixel Code -->
        <script>
            !(function (f, b, e, v, n, t, s) {
                if (f.fbq) return;
                n = f.fbq = function () {
                    n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
                };
                if (!f._fbq) f._fbq = n;
                n.push = n;
                n.loaded = !0;
                n.version = "2.0";
                n.queue = [];
                t = b.createElement(e);
                t.async = !0;
                t.src = v;
                s = b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t, s);
            })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
            fbq("init", "1194857871916987");
            fbq("track", "PageView");
        </script>
        <noscript>
            <img height="1" width="1" style="display: none;" src="https://www.facebook.com/tr?id=1194857871916987&ev=PageView&noscript=1" />
        </noscript>
        <!-- End Facebook Pixel Code -->
    </head>

    <body class="preloader gtd-body-hidden">
        <!-- <div class="preloaders2" style="text-align: center;">
            <div class="cssload-thecube">
                <div class="cssload-cube cssload-c1"></div>
                <div class="cssload-cube cssload-c2"></div>
                <div class="cssload-cube cssload-c4"></div>
                <div class="cssload-cube cssload-c3"></div>
            </div>
            <div style="font-weight: bold; padding-top: 34px; color: white;">Processing</div>
        </div> -->

        <div class="hover-modal"></div>
        <div id="popup_custom" class="popup_custom">
            <div class="popup_overlay"></div>
            <a class="close_button" id="close_button">×</a>
            <div class="popup_inner">
                <div class="popup_content">
                    <div class="popup_content_inner">
                        <div class="popup-content-wrapper">
                            <div class="popup-header">
                                <div class="title">
                                    Только что вы совершили БОЛЬШУЮ ошибку!
                                </div>
                                <div class="subtitle">Это ваш <b>ПОСЛЕДНИЙ ШАНС</b> присоединиться к <b>Bitcoin Bank</b> и обеспечить свое финансовое будущее.</div>
                            </div>
                        </div>
                        <div class="popup-form-wrapper">
                            <div class="form-container-unique">
                                <div class="form-block-2 whitee">
                                    <div class="col-xs-12" style="width: 100%; margin: 0 auto;">
                                        <div class="buttonReg scroll-close" id="scroll-close" style="background-color: #1682ff;">Получить доступ сейчас!</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- INTRO SECTION 1 START -->
        <section class="intro-section-1" style="padding: 15px 0 10px 0;">
            <div style="display: inline-block; position: absolute; top: 4px; left: 50%; transform: translateX(-50%); font-size: 0.5em; opacity: 0.5; font-family: inherit;">-�&nbsp;Advertorial�&nbsp;-</div>

            <div class="container">
                <p class="intro-p">
                    <b data-i18n="warning">Внимание</b>: <span data-i18n="due-to"> В связи с высоким вниманием медиа, мы закроем регистрацию </span>
                    <b>
                        <b><span class="tomorrow-date">05/07/2019</span> - <span>Поспешите!</span> </b><span class="countdown-span" id="timer">05:30</span>
                    </b>
                </p>
            </div>
        </section>
        <!-- INTRO SECTION 1 END -->
        <!-- INTRO SECTION 2 START -->
        <section class="intro-section-2">
            <div class="container">
                <div class="intro-part-2">
                    <img src="images/logo1.webp" alt="logo" class="logo">
                </div>
            </div>
        </section>
        <!-- INTRO SECTION 2 END -->
        <!-- VIDEO FORM SECTION START -->
        <section class="video-form-section">
            <div class="container">
                <h1 class="video-header">Bitcoin Делает Людей Богатыми</h1>
                <p class="video-subheader"><span>И ты можешь стать</span> <span class="yellow"> Следующим Миллионером...</span></p>
                <div class="row" style="margin-bottom: -157px;">
                    <div class="col-md-12 col-lg-8">
                        <div class="video-wrapper">
                            <div class="video embed-responsive ">
                                <script src="js/xeEu47Q1-PbLFVgxG.js"></script>
                                <!-- <iframe
                                    width="640"
                                    height="370"
                                    src="https://www.youtube.com/embed/1we_WVEgiA8"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen
                                ></iframe> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-4">
                        <div class="form-container">
                            <div class="formwrap-outer">
                                <div class="formwrap">
                                    <div class="form-body">
                                        <div class="gtd-form-step-2" data-subject="slide-wrapper" id="lead--form">
                                            
                                            <form class="main_form register-form" id="leadform1">
                                                <div class="input_wrapper">
                                                    <div class="form-group input-group input-wrap">
                                                        <input class="form-control" type="text" name="fname" placeholder="Имя" id="name1" />
                                                        <p class="error error-fname"></p>
                                                    </div>
                                                    <div class="form-group input-group input-wrap">
                                                        <input class="form-control" type="text" name="lname" placeholder="Фамилия" id="name1" />
                                                        <p class="error error-lname"></p>
                                                    </div>
                                                    <div class="form-group input-group input-wrap">
                                                        <input class="form-control" type="email" name="email" placeholder="Email" id="email1" />
                                                        <p class="error error-email"></p>
                                                    </div>
                                                    <div class="form-group input-group input-wrap">
                                                        <div class="iti__flag-container">
                                                            <ul class="iti__country-list iti__hide" id="iti-0__country-listbox" role="listbox"
                                                                aria-label="List of countries">
                                                            </ul>
                                                        </div>
                                                        <input placeholder type="tel" name="fullphone" autocomplete="on" class="form-control"
                                                            style="width: 100%;" />
                                                        <p class="error error-fullphone"></p>
                                                    </div>
                                                    <!-- обязательно -->
                                                    <input type="hidden" name="csrf" value="<?= $csrf; ?>" />
                                                    <input type="hidden" name="phoneCountryCode" value="" />
                                                    <input type="hidden" name="phoneCountry" value="<?= $country_code; ?>" />
                                                    <input type="hidden" name="ip" value="<?= $ip; ?>" />
                                                    <input type="hidden" name="geoCountry" value="<?= $country_code; ?>" />
                                                    <input type="hidden" name="query_str" value="" />
                                                    <div class="data_php" data-attr="<?= $ip; ?>"></div>
                                                    <div class="data_php_1" data-attr="<?= $country_code; ?>"></div>
                                                    <!-- обязательно -->
                                                    <div class="form-group">
                                                        <button class="submit_btn btn secondary-solid-btn btn-block" name="submitBtn" type="submit">Получить доступ сейчас</button>
                                                    </div>
                                            
                                                </div>
                                                <div class="form_message error inactive "
                                                    style="margin:15px 0;background-color: #ffd4d4;border: 2px dashed #ce0909;border-radius: 10px;padding: 20px;">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="confirm-text_links col-md-4 offset-md-8 col-xs-12">
                        <div class="checkbox-svg">
                            <input type="checkbox" id="cbx" style="display: none;" checked="">
                            <label for="cbx" class="checked-svg">
                                <svg width="20px" height="20px" viewBox="0 0 18 18">
                                    <path d="M1,9 L1,3.5 C1,2 2,1 3.5,1 L14.5,1 C16,1 17,2 17,3.5 L17,14.5 C17,16 16,17 14.5,17 L3.5,17 C2,17 1,16 1,14.5 L1,9 Z"></path>
                                    <polyline points="1 9 7 14 15 4"></polyline>
                                </svg>
                            </label>
                            <div class="privacy-checkbox">
                                <p>
                                    Я даю согласие на сбор адреса моей электронной почты в целях получения коммерческих предложений, которые, по нашему мнению, будут представлять интерес для вас от имени компаний и отраслей, подробно
                                    описанных в наших
                                    <a href="terms.html" target="_blank"> Условиях пользования</a>
                                    и
                                    <a href="privacy.html" target="_blank"> Политике конфиденциальности.</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!---->
                </div>
            </div>
        </section>

        <!-- LOGOS SECTION START -->
        <section class="logos-section">
            <div class="container">
                <div class="logos-wrapper">
                    <img src="images/bitgo.webp" class="logo" alt="bitgo logo">
                    <img src="images/norton.webp" class="logo" alt="norton logo">
                    <img src="images/secure-trading.webp" class="logo" alt="secure trading logo">
                    <img src="images/mcafee.webp" class="logo" alt="mcafee logo">
                </div>
            </div>
        </section>
        <!-- LOGOS SECTION END -->

        <!-- JOIN US SECTION START -->
        <section class="join-us-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1 class="join-us-header">
                            <span>Присоединяйся и Стань богатым </span>
                            <span style="color: #5f3394;">c Bitcoin Bank!</span>
                        </h1>
                        <br>
                        <p class="join-us-p">
                            <span>
                                Bitcoin Bank - это эксклюзивная группа для людей, которые поверили и втянулись в безумие Bitcoin и заработали на нём целое состояние. Участники проекта, каждый месяц наслаждаются отдыхом по всему миру, в то время как
                                зарабатывают деньги на своем ноутбуке всего за несколько минут «работы», каждый день.
                            </span>
                        </p>
                    </div>
                </div>
            </div>
        </section>
        <!-- JOIN US SECTION END -->

        <!-- TESTIMONIALS SECTION START -->
        <section class="testimonials-section">
            <div class="container-fluid">
                <h1 class="testimonials-header purple">Реальные отзывы от наших участников</h1>
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-lg-3 no-padding">
                        <div class="testimonial-wrapper testimonial-wrapper-1">
                            <div class="testimonial-intro-text white">
                                <span>Владимир И.</span> <br>
                                <span>Стамбул</span> <br>
                                <span class="yellow testimonial-profit-span">
                                    <span>Прибыль</span>: <span data-init="visitor-currency-symbol"><span class="currency">$</span></span>10,987.98
                                </span>
                            </div>
                            <div class="testimonial-hover-text">
                                <i>
                                    'Я был участником системы Bitcoin Bank всего 47 дней. Но моя жизнь уже изменилась! Я не только заработал мои первые <span class="currency">$</span>10,000, я так же встретил самых удивительных людей в
                                    процессе. Спасибо, Bitcoin Bank!'
                                </i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-lg-3 no-padding">
                        <div class="testimonial-wrapper testimonial-wrapper-2">
                            <div class="testimonial-intro-text white">
                                <span>Зоя А.</span> <br>
                                <span>Тель-Авив</span> <br>
                                <span class="yellow testimonial-profit-span">
                                    <span>Прибыль</span>: <span data-init="visitor-currency-symbol"><span class="currency">$</span></span>6,109.09
                                </span>
                            </div>
                            <div class="testimonial-hover-text">
                                <i>'Теперь я знаю как это жить мечтой. Я больше не чувствую, будто я вне игры, пока другие веселятся. Bitcoin Bank, позволил мне рано уйти с работы и быть одним из 1% счастливчиков.'</i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-lg-3 no-padding">
                        <div class="testimonial-wrapper testimonial-wrapper-3">
                            <div class="testimonial-intro-text white">
                                <span>Марк К.</span> <br>
                                <span>Лондон</span> <br>
                                <span class="yellow testimonial-profit-span">
                                    <span>Прибыль</span>: <span data-init="visitor-currency-symbol"><span class="currency">$</span></span>8,938.79
                                </span>
                            </div>
                            <div class="testimonial-hover-text">
                                <i>
                                    'Как ни странно, я был инвестором в одной из компаний в Москва-сити и никогда не видел ничего подобного за свой 10 летний стаж там. Мои коллеги, думали что я сумасшедший, когда я ушёл с работы чтобы
                                    инвестировать в программу Bitcoin Bank. Заработав <span class="currency">$</span>38,459 чистой прибыли, мои бывшие коллеги УМОЛЯЮТ меня рассказать им как у меня получилось!'
                                </i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-lg-3 no-padding">
                        <div class="testimonial-wrapper testimonial-wrapper-4">
                            <div class="testimonial-intro-text white">
                                <span>Жанна Н.</span><br>
                                <span>Тбилиси</span> <br>
                                <span class="yellow testimonial-profit-span">
                                    <span>Прибыль</span>: <span data-init="visitor-currency-symbol"><span class="currency">$</span></span>7,234.98
                                </span>
                            </div>
                            <div class="testimonial-hover-text">
                                <i>
                                    'Две недели назад меня уволили. Без вариантов, я думала моя жизнь кончена. Теперь я зарабатываю <span class="currency">$</span>1,261.42 каждый день. Впервые за 2 месяца я не в долгах. Спасибо, Bitcoin
                                    Bank!'
                                </i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- TESTIMONIALS SECTION END -->

        <!-- FEATURES SECTION START -->
        <section class="features-section text-center">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 feature-wrapper-col">
                        <div class="feature-wrapper">
                            <div class="feature-img-wrapper">
                                <img src="images/feature-img-1.webp" class="feature-img" alt="feature 1">
                            </div>
                            <h5 class="feature-header">Точность Лазера</h5>
                            <p class="feature-description">
                                В мире нет другого торгового приложения как Bitcoin Bank, которое дает 99.4% точности. Поэтому, наши участники со всего мира доверяют нам удваивать и утраивать их тяжело заработанные деньги.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 feature-wrapper-col">
                        <div class="feature-wrapper">
                            <div class="feature-img-wrapper">
                                <img src="images/feature-img-2.webp" class="feature-img" alt="feature 1">
                            </div>
                            <h5 class="feature-header">Улучшенная технология</h5>
                            <p class="feature-description">
                                Программа Bitcoin Bank была создана самыми продвинутыми технологиями торговли в мире. Программа опережает рынок на 0.01 секунды. Этот 'скачек времени' позволяет Bitcoin Bank быть самой точной и быстрой
                                программой в мире.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 feature-wrapper-col">
                        <div class="feature-wrapper">
                            <div class="feature-img-wrapper">
                                <img src="images/feature-img-3.webp" class="feature-img" alt="feature 1">
                            </div>
                            <h5 class="feature-header">Программа выигрывающая награды</h5>
                            <p class="feature-description">Приложение Bitcoin Bank выиграло множество наград. Недавно мы имели честь получить награду 'номер 1', в категории торговых программ от Торговой US Ассоциации.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- FEATURES SECTION END -->

        <!-- LIVE RESULTS SECTION START-->
        <section class="live-results-section text-center">
            <div class="container relative">
                <div class="live-results-table-wrapper">
                    <button class="yellow-btn join-now-btn scroll-top-btn">
                        <span>Присоединиться!</span>
                    </button>
                    <h1 class="dark-purple bold live-results-header">Таблица доходов в реальном времени</h1>
                    <table class="live-results-table">
                        <thead class="thead">
                            <tr>
                                <th class="dark-purple padding-left-td">Имя</th>
                                <th class="dark-purple padding-left-td">Доход</th>
                                <th class="dark-purple padding-left-td">Время Сделки</th>
                                <th class="dark-purple padding-left-td">Криптовалюта</th>
                                <th class="dark-purple padding-left-td">Результат</th>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            <tr>
                                <td class="bold">
                                    Зоя Румянцевa.
                                </td>
                                <td class="bold"><span class="currency">$</span>996</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>ETH/LTC</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Денис Черемнов.
                                </td>
                                <td class="bold"><span class="currency">$</span>815</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>EOS/ETH</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Арина Алексеевa.
                                </td>
                                <td class="bold"><span class="currency">$</span>481</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>EOS/ETH</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Ефим Щеглов.
                                </td>
                                <td class="bold"><span class="currency">$</span>1294</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>BTC/ETH</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Юрий Кац.
                                </td>
                                <td class="bold"><span class="currency">$</span>1224</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>EOS/ETH</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Валентин Жданов.
                                </td>
                                <td class="bold"><span class="currency">$</span>434</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>EOS/ETH</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Рената Герасимовa.
                                </td>
                                <td class="bold"><span class="currency">$</span>924</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>BTC/ETH</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Дарья Евсеевa.
                                </td>
                                <td class="bold"><span class="currency">$</span>532</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>ETH/LTC</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold">
                                    Владислав Моисеенко.
                                </td>
                                <td class="bold"><span class="currency">$</span>951</td>
                                <td class="trade-time-td padding-left-td">18/7/2019</td>
                                <td>EOS/ETH</td>
                                <td><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                            <tr>
                                <td class="bold last-td">
                                    Филипп Харинов.
                                </td>
                                <td class="bold last-td"><span class="currency">$</span>1151</td>
                                <td class="trade-time-td padding-left-td last-td">18/7/2019</td>
                                <td class="last-td">EOS/ETH</td>
                                <td class="last-td"><img src="images/tick.webp" alt="tick"></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="currency--table-hide" style="display: none;"></div>
                </div>
            </div>
        </section>
        <!-- LIVE RESULTS SECTION END -->
        <!-- HOW IT WORKS SECTION START -->
        <section class="how-it-works-section text-center">
            <div class="container">
                <div class="how-it-works-wrapper">
                    <h1 class="dark-purple bold how-it-works-header">Как это работает</h1>
                    <div class="row">
                        <div class="col-md-4 no-padding step-wrapper-col">
                            <div class="step-wrapper step-wrapper-1">
                                <h3 class="step-header white step-header-1">Шаг 1</h3>
                                <div class="step-img-wrapper">
                                    <img src="images/step-img-1.webp" alt="step 1" class="step-img">
                                </div>
                                <h5 class="step-subheader bold dark-purple">Регистрация на сайте</h5>
                                <p class="step-description">
                                    Как только ваша регистрация будет принята, вы автоматически становитесь новым пользователем системы Bitcoin Bank. Вы получите возможность пользоваться торговой системой без ограничений.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4 no-padding step-wrapper-col">
                            <div class="step-wrapper step-wrapper-2">
                                <h3 class="step-header white step-header-2">Шаг 2</h3>
                                <div class="step-img-wrapper">
                                    <img src="images/step-img-2.webp" alt="step 2" class="step-img">
                                </div>
                                <h5 class="step-subheader bold dark-purple">Пополните ваш аккаунт</h5>
                                <p class="step-description">
                                    <span>
                                        Как любой другой бизнес, вам нужен стартовый капитал чтобы начать. Чтобы начать получать прибыль с системой Bitcoin Bank, вы должны инвестировать <span class="currency">$</span>250 или больше.
                                    </span>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4 no-padding step-wrapper-col">
                            <div class="step-wrapper last-step-wrapper step-wrapper-3">
                                <h3 class="step-header white step-header-3">Шаг 3</h3>
                                <div class="step-img-wrapper">
                                    <img src="images/step-img-3.webp" alt="step 3" class="step-img">
                                </div>
                                <h5 class="step-subheader bold dark-purple">Финиш</h5>
                                <p class="step-description">
                                    Нажмите 'торговать' чтобы начать точный путь к автоматической торговли, созданной по выигрышному алгоритму. Так же, если Вам нужно, Вы можете перевести систему в ручной режим, если предпочитаете торговать сами.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="how-it-works-btn-wrapper">
                <button class="yellow-btn open-free-account-btn scroll-top-btn">
                    <span>Создайте прибыльный аккаунт</span>
                </button>
            </div>
        </section>
        <!-- HOW IT WORKS SECTION END -->
        <!-- FAQ SECTION START -->
        <section class="faq-section">
            <div class="container">
                <h2 class="faq-section-header text-center dark-purple bold">Часто задаваемые вопросы</h2>
                <div class="row">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-11">
                                <div class="faq-wrapper faq-wrapper-1">
                                    <h4 class="faq-question light-purple bold">Какой результат я могу ожидать?</h4>
                                    <p class="faq-answer">Пользователи Bitcoin Bank обычно получают минимальную прибыль в размере <span class="currency">$</span>1100 ежедневно.</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-11">
                                <div class="faq-wrapper faq-wrapper-2">
                                    <h4 class="faq-question light-purple bold">Как много часов в день мне придётся работать?</h4>
                                    <p class="faq-answer">Наши пользователи работают в среднем 20 минут в день, а то и меньше. Программа берет на себя всю торговую работу, поэтому она минимизирует Ваше рабочее время.</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-11">
                                <div class="faq-wrapper faq-wrapper-3">
                                    <h4 class="faq-question light-purple bold">Какая максимальная прибыль которую я могу получить?</h4>
                                    <p class="faq-answer">С Bitcoin Bank ваша прибыль не имеет границ. Некоторые пользователи заработали первый миллион всего за 61 день.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-11">
                                <div class="faq-wrapper faq-wrapper-4">
                                    <h4 class="faq-question light-purple bold">Сколько стоит программа?</h4>
                                    <p class="faq-answer">Участники проекта Bitcoin Bank получают копию программы. Чтобы стать пользователем, просто заполните форму на этой странице.</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-11">
                                <div class="faq-wrapper faq-wrapper-5">
                                    <h4 class="faq-question light-purple bold">Является ли эта система MLM или партнерским маркетингом?</h4>
                                    <p class="faq-answer">Наша система, не является MLM, партнерским маркетингом или чем-либо еще. Эта система выигрывает торги с вероятностью в 91.4%.</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-11">
                                <div class="faq-wrapper faq-wrapper-6">
                                    <h4 class="faq-question light-purple bold">Берет ли система комиссию?</h4>
                                    <p class="faq-answer">В системе нет скрытых комиссий и комиссии брокера. Все ваши деньги на 100% ваши и вы можете с легкостью вывести их в любое время, без задержек.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- FAQ SECTION END -->
        <!-- PRE-FOOTER SECTION START -->
        <section class="pre-footer-section">
            <div class="container">
                <button class="pre-footer-btn scroll-top-btn">
                    <span>НАЧАТЬ СЕЙЧАС</span>
                </button>
            </div>
        </section>
        <!-- PRE-FOOTER SECTION END -->
        <!-- FOOTER START -->
        <footer class="footer text-center">
            <div class="container">
                <ul class="footer-ul">
                    <li><a id="terms" href="terms.html" target="_blank">Условия пользования</a></li>
                    <li><a id="privacy-policy" href="privacy.html" target="_blank">Политика конфиденциальности</a></li>
                </ul>
                <img src="images/logo1.webp" class="footer-logo" alt="logo">
            </div>
        </footer>

        <link rel="stylesheet" type="text/css" href="css/css.css">
        <link rel="stylesheet" type="text/css" href="css/index.css">
        <!-- Funnels SDK Init -->
        <link rel="stylesheet" href="css/main.min.css">
        <link rel="stylesheet" href="css/pop-up.css">
        <script src="js/index.js"></script>

        <!-- intlTelInput -->
        <!-- <link rel="stylesheet" href="css/intlTelInput.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
        <script src="js/intlTelInput.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
     -->
        <style>
            .error {
                background-color: rgba(255, 0, 0, 0.5) !important;
            }
            .valid {
                background-color: rgba(0, 255, 0, 0.5) !important;
            }
            .modal_phone {
                opacity: 1;
                position: fixed;
                top: 0;
                bottom: 0;
                right: 0;
                left: 0;
                z-index: 99999;
                display: none;
                outline: 0;
                padding-right: 15px;
                justify-content: center;
                align-items: center;
                background-color: rgba(0, 0, 0, 0.4);
                overflow-x: hidden;
                overflow-y: auto;
                color: #000;
            }

            .modal_phone.open_phone {
                display: flex;
            }

            .modal-open_phone {
                overflow: hidden;
            }

            .modal-dialog_phone {
                position: relative;
                width: 100%;
                max-width: 32rem;
                padding: 1rem;
                box-sizing: border-box;
            }

            .modal-content_phone {
                display: flex;
                flex-direction: column;
                pointer-events: auto;
                background-color: #fff;
                background-clip: padding-box;
                border: 1px solid rgba(0, 0, 0, 0.2);
                border-radius: 0.3rem;
                outline: 0;
            }

            .modal-header_phone {
                display: flex;
                align-items: center;
                padding: 1rem 1rem;
            }

            .modal-header_phone {
                justify-content: space-between;
                border-top-left-radius: 0.3rem;
                border-top-right-radius: 0.3rem;
            }

            .modal-body_phone {
                position: relative;
                flex: 1 1 auto;
                padding: 1rem;
            }

            .modal-title_phone {
                font-size: 1.25rem;
                font-weight: 600;
            }

            .close-button_phone {
                font-size: 1.5rem;
                font-weight: 700;
                line-height: 1;
                opacity: 0.5;
                background-color: transparent;
                border: 0;
                cursor: pointer;
                padding: 1rem 1rem;
                margin: -1rem -1rem -1rem auto;
            }
        </style>

        <div id="modal_phone" class="modal_phone fade_phone" tabindex="-1">
            <div class="modal-dialog_phone">
                <div class="modal-content_phone">
                    <div class="modal-header_phone">
                        <h5 class="modal-title_phone">Неверный телефон</h5>
                        <button type="button" class="close-button_phone" id="close-button_phone">×</button>
                    </div>
                    <div class="modal-body_phone">
                        Извините! Программа не поддерживается в вашем регионе. Введите ваш Европейский номер для участия в программе
                    </div>
                </div>
            </div>
        </div>

        <script>
            function parseURLParams(url) {
                var queryString = url ? url.split("?")[1] : window.location.search.slice(1);
                var obj = {};

                if (queryString) {
                    queryString = queryString.split("#")[0];
                    var arr = queryString.split("&");

                    for (var i = 0; i < arr.length; i++) {
                        var a = arr[i].split("=");
                        var paramName = a[0];
                        var paramValue = typeof a[1] === "undefined" ? true : a[1];

                        if (paramName.match(/\[(\d+)?\]$/)) {
                            var key = paramName.replace(/\[(\d+)?\]/, "");
                            if (!obj[key]) obj[key] = [];

                            if (paramName.match(/\[\d+\]$/)) {
                                var index = /\[(\d+)\]/.exec(paramName)[1];
                                obj[key][index] = paramValue;
                            } else {
                                obj[key].push(paramValue);
                            }
                        } else {
                            if (!obj[paramName]) {
                                obj[paramName] = paramValue;
                            } else if (obj[paramName] && typeof obj[paramName] === "string") {
                                obj[paramName] = [obj[paramName]];
                                obj[paramName].push(paramValue);
                            } else {
                                obj[paramName].push(paramValue);
                            }
                        }
                    }
                }

                return obj;
            }

            const { fbclid, app_id } = parseURLParams(location.href);

            const openModal = () => {
                document.getElementById("modal_phone").classList.add("open_phone");
                document.body.classList.add("modal-open_phone");
            };

            const closeModal = () => {
                document.getElementById("modal_phone").classList.remove("open_phone");
                document.body.classList.remove("modal-open_phone");
            };

            document.getElementById("close-button_phone").addEventListener("click", closeModal);

            $(document).ready(function () {
                let phonePrefix = "44";

                $.ajax({
                    url: "https://getyourapi.site/api/geolocation",
                    dataType: "json",
                    success: function (result) {
                        $('input[name="phone"]').each(function (input) {
                            let iti = intlTelInput(this, {
                                ...result.data,
                                autoHideDialCode: "true",
                                customContainer: "phoneWrapper",
                                autoPlaceholder: "aggressive",
                                separateDialCode: "false",
                                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/utils.min.js",
                            });
                            phonePrefix = iti.getSelectedCountryData().dialCode;
                            $(this).on("countrychange", function () {
                                phonePrefix = iti.getSelectedCountryData().dialCode;
                            });
                            return iti;
                        });
                    },
                });

                function validateEmail(email) {
                    return /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/.test(String(email).toLowerCase());
                }

                function changInputHandler(e) {
                    if (e.target.value.length === 0) {
                        this.classList.remove("valid");
                        this.classList.add("error");
                        return;
                    }
                    this.classList.add("valid");
                    this.classList.remove("error");
                }
                function changEmailHandler(e) {
                    if (validateEmail(e.target.value) === false) {
                        this.classList.add("error");
                        this.classList.remove("valid");
                        return;
                    }
                    this.classList.add("valid");
                    this.classList.remove("error");
                }

                $(".form-input").keyup(changInputHandler);
                $(".form-input").change(changInputHandler);
                $("input[name = email]").keyup(changEmailHandler);
                $("input[name = email]").change(function (e) {});
                $("form.register-form").submit(function (e) {
                    e.preventDefault();
                    $(".loader").css("display", "block");
                    const button = $("button[name=submitBtn]");
                    button.prop("disabled", true);
                    const form = $(this);

                    const first_name = form.find("input[name = first_name]");
                    const last_name = form.find("input[name = last_name]");
                    const email = form.find("input[name = email]");
                    const phone = form.find("input[name = phone]");

                    let isError = false;
                    if (first_name.val() === "") {
                        first_name.addClass("error").val("").attr("placeholder", "Enter your name");
                        isError = true;
                    }

                    if (last_name.val() === "") {
                        last_name.addClass("error").val("").attr("placeholder", "Enter your last name");
                        isError = true;
                    }

                    if (phone.val() === "") {
                        phone.addClass("error").val("").attr("placeholder", "Enter your phone number");
                        isError = true;
                    }

                    if (validateEmail(email.val()) === false) {
                        email.addClass("error").val("").attr("placeholder", "You entered an incorrect email address");
                        isError = true;
                    }

                    if (isError === true) {
                        button.prop("disabled", false);
                        $(".loader").css("display", "none");
                        return;
                    }

                    const checkNumber = new Promise((resolve, reject) => {
                        $.ajax({
                            url: "https://getyourapi.site/api/phone/validate",
                            type: "post",
                            contentType: "application/json",
                            data: JSON.stringify({
                                phone: `${phonePrefix}${phone.val()}`,
                            }),
                            success: resolve,
                            error: reject,
                        });
                    });
                    const getBlacklist = new Promise(function (resolve, reject) {
                        $.ajax({
                            url: "https://getyourapi.site/api/blacklist",
                            type: "get",
                            contentType: "application/json",
                            success: resolve,
                            error: reject,
                        });
                    });

                    Promise.all([checkNumber, getBlacklist])
                        .then(([checkNumber, blacklist]) => {
                            if (checkNumber.status === false) {
                                button.prop("disabled", false);
                                $(".loader").css("display", "none");
                                phone.addClass("error").removeClass("valid").val("").attr("placeholder", "The phone number entered is incorrect");
                                return false;
                            }

                            if (blacklist.status === false) {
                                button.prop("disabled", false);
                                $(".loader").css("display", "none");
                                return false;
                            }

                            if (blacklist.data.blacklist.includes(checkNumber.data.country_code.toLowerCase())) {
                                button.prop("disabled", false);
                                $(".loader").css("display", "none");
                                openModal();
                                setTimeout(closeModal, 5000);

                                return false;
                            }

                            $.ajax({
                                url: "https://getyourapi.site/api/leads/app",
                                type: "post",
                                contentType: "application/json",
                                data: JSON.stringify({
                                    first_name: first_name.val(),
                                    last_name: last_name.val(),
                                    email: email.val(),
                                    phone: phone.val(),
                                    country: checkNumber.data.country_code,
                                    app_id: app_id,
                                    click_id: fbclid,
                                }),
                                dataType: "json",
                                success: function (res) {
                                    if (res.status === true) {
                                        fbq("track", "Lead");
                                        fbq("track", "CompleteRegistration");
                                        cnv_pixel();
                                        switch (res.data.proceedWith) {
                                            case "success":
                                                window.location.href = "./success.html" ;
                                                break;
                                            case "exist":
                                                window.location.href = "./error.html" ;
                                                break;
                                            case "redirect":
                                                window.location.href = res.data.redirectUrl;
                                                break;
                                            default:
                                                window.location.href = "./success.html" ;
                                        }
                                        console.log("click");
                                    } else {
                                        alert("Error! Please try again.");
                                        $(".loader").css("display", "none");
                                        button.prop("disabled", false);
                                    }
                                },
                                error: function (error) {
                                    button.prop("disabled", false);
                                    $(".loader").css("display", "none");
                                    console.error(error);
                                },
                            });
                        })
                        .catch(function (error) {
                            button.prop("disabled", false);
                            $(".loader").css("display", "none");
                            console.error(error);
                        });
                });
            });
        </script>
        <style>
            .form_message.error.inactive {
                display: none;
            }
    
            .form_message.error.active {
                display: block;
                color: #0a0a0a;
            }
        </style>
        <script>
            var x = new Date();
            var TimeZone = x.getTimezoneOffset() / 60;
    
            if (Math.sign(TimeZone) == -1) {
                var TimeZone = TimeZone.toString().replace("-", "");
            } else {
                var TimeZone = "-" + TimeZone;
            }
    
            document.querySelectorAll('[name="timezone"]').forEach(function (item) {
                item.value = TimeZone;
            });
        </script>
    
        <style>
            .error-border {
                border: dashed 1px #ce0909;
            }
    
            p.error-msg {
                margin: 0;
                color: #ce0909;
                padding: 5px 0 0;
                font-size: 14px;
                font-style: italic;
            }
    
            .modal {
                display: none;
                /* Hidden by default */
                position: fixed;
                /* Stay in place */
                z-index: 1;
                /* Sit on top */
                left: 0;
                top: 0;
                width: 100%;
                /* Full width */
                height: 100%;
                /* Full height */
                overflow: auto;
                /* Enable scroll if needed */
                background-color: rgb(0, 0, 0);
                /* Fallback color */
                background-color: rgba(0, 0, 0, 0.4);
                /* Black w/ opacity */
                -webkit-animation-name: fadeIn;
                /* Fade in the background */
                -webkit-animation-duration: 0.4s;
                animation-name: fadeIn;
                animation-duration: 0.4s
            }
    
            .modal-content {
                position: fixed;
                left: 50%;
                top: 20%;
                transform: translate(-50%, 0);
                background-color: #fefefe;
                max-width: 400px;
                min-height: 300px;
                -webkit-animation-name: slideIn;
                -webkit-animation-duration: 0.4s;
                animation-name: slideIn;
                animation-duration: 0.4s
            }
    
            .close {
                color: white;
                float: right;
                font-size: 28px;
                font-weight: bold;
            }
    
            .close:hover,
            .close:focus {
                color: #000;
                text-decoration: none;
                cursor: pointer;
            }
    
            .modal-header {
                padding: 2px 16px;
                background-color: #ff1838;
                color: white;
            }
    
            .modal-body {
                padding: 16px;
                text-align: center;
            }
    
    
            /* Add Animation */
            @-webkit-keyframes slideIn {
                from {
                    opacity: 0
                }
    
                to {
                    bottom: 0;
                    opacity: 1
                }
            }
    
            @keyframes slideIn {
                from {
                    opacity: 0
                }
    
                to {
                    bottom: 0;
                    opacity: 1
                }
            }
    
            @-webkit-keyframes fadeIn {
                from {
                    opacity: 0
                }
    
                to {
                    opacity: 1
                }
            }
    
            @keyframes fadeIn {
                from {
                    opacity: 0
                }
    
                to {
                    opacity: 1
                }
            }
    
            /* preloader */
            .preloader {
                display: block !important;
                position: absolute;
                left: 0;
                top: 0;
                z-index: 99;
                width: 100%;
                height: 100%;
                overflow: visible;
                background: #fbfbfb url('//cdnjs.cloudflare.com/ajax/libs/file-uploader/3.7.0/processing.gif') no-repeat center center;
                opacity: 1;
                transition: opacity 2s linear;
            }
    
            .preloader-visible {
                visibility: visible;
                opacity: 1;
                transition: opacity 2s linear;
            }
    
            .preloader-hidden {
                visibility: hidden;
                opacity: 0;
                transition: visibility 0s 2s, opacity 2s linear;
            }
        </style>
    
    
        <!-- <script src="intl-tel-input/js/intlTelInput.js"></script>
        <script src="intl-tel-input/js/utils.js"></script> -->
        <script src="./intl-tel-input/js/intlTelInput.js"></script>
        <script src="./intl-tel-input/js/utils.js"></script>
    
        <!-- <script src="js/main.js"></script>
        <script src="js/validate.js"></script> -->
        <script src="js/main.js"></script>
        <script src="js/validate.js"></script>
    
        <script>
            initialization();
            registration(FIELDS);
        </script>
    

</body></html>